package hw4;

/**
 * Score box that is satisfied by any Combination.
 * The score is the sum of all die values.
 * 
 * @author YOUR NAME HERE
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class ChanceScoreBox
{
  /**
   * Constructs a ChanceScoreBox with the given display name.
   * @param displayName
   *   name for this score box
   */
  public ChanceScoreBox(String displayName)
  {
    // TODO
  }

}
