package hw4;

/**
 * Score box for a short straight.  A Combination
 * with N dice satisfies this category only if it includes
 * N - 1 distinct consecutive values.  For a dice group that satisfies
 * this category, the score is a fixed value specified in the constructor;
 * otherwise, the score is zero.
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class ShortStraightScoreBox
{
  /**
   * Constructs a SmallStraightScoreBox with the given display name
   * and score.
   * @param displayName
   *   name of this score box
   * @param points
   *   points awarded for a dice group that satisfies this score box
   */  
  public ShortStraightScoreBox(String displayName, int points)
  {
    // TODO
  }

}
