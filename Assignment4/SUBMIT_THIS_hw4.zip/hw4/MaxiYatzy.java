package hw4;

import java.util.ArrayList;
import java.util.Random;

import api.GameConfiguration;
import api.ScoreBox;

/**
 * Game state for dice games such as MaxiYatzy. The game includes a
 * <code>GameConfiguration</code> object along with two lists of
 * <code>ScoreBox</code> objects, one for the upper section and one for the
 * lower section. (Note that the only actual distinction between the two
 * sections is that the upper section scores are added up and checked to see
 * whether they exceed the upper section bonus cutoff; if so, the upper section
 * bonus is added to the score.) This class is also responsible for maintaining
 * a current Combination (group of dice) and counting the number of rolls.
 * <p>
 * Most of the game state is stored in the associated <code>ScoreBox</code>
 * objects, each of which knows its contribution to the overall score, obtained
 * via its <code>getScore</code> method.
 * 
 * @author VITAL NYABSHI
 */
public class MaxiYatzy {
	private ScoreBox lowValue;
	private ScoreBox upperValue;
	private ArrayList<ScoreBox> lowValues = new ArrayList<>();
	private ArrayList<ScoreBox> upperValues = new ArrayList<>();
	private Combination com;
	private GameConfiguration configuration;
	private Random random;
	private int availableRolls;
	private int[] availableDice;
	private int upperSecBonus;
	private int lowerSecTotal = 0;
	private int upperSecTotal = 0;

	public MaxiYatzy(GameConfiguration config, Random rand) {
		configuration = config;
		random = rand;
		availableRolls = 0;
	}

	public void addLowerSectionScoreBox(ScoreBox box) {
		lowValue = box;
		lowValues.add(lowValue);
	}

	public void addUpperSectionScoreBox(ScoreBox box) {
		upperValue = box;
		upperValues.add(box);
	}

	public ArrayList<ScoreBox> getUpperSection() {
		return upperValues;
	}

	public ArrayList<ScoreBox> getLowerSection() {
		return lowValues;
	}

	public void startTurn() {
		com = new Combination(configuration.getNumDice());
		if (configuration.allowSavedRolls()) {
			availableRolls += configuration.getMaxRolls();
		} else {
			availableRolls = configuration.getMaxRolls();
		}
	}

	public int getRemainingRolls() {
		return availableRolls;
	}

	public void rollAvailableDice() {
		availableRolls--;
		availableDice = com.getAvailableDice();
		for (int i = 0; i < availableDice.length; i++) {
			availableDice[i] = random.nextInt(configuration.getMaxValue()) + 1;
		}
		com.updateAvailableDice(availableDice);
		if (availableRolls <= 0) {
			com.chooseAll();
		}
	}

	public Combination getCurrentDice() {
		return com;
	}

	public boolean isOver() {
		return availableRolls <= 0;
	}

	public int getUpperSectionTotal() {
		upperSecTotal = 0;
		for (ScoreBox box : upperValues) {
			if (box.isFilled()) {
				upperSecTotal += box.getScore();
			}
		}
		return upperSecTotal;
	}

	public int getLowerSectionTotal() {
		lowerSecTotal = 0;
		for (ScoreBox box : lowValues) {
			if (box.isFilled()) {
				lowerSecTotal += box.getScore();
			}
		}
		return lowerSecTotal;
	}

	public int getTotalScore() {
		int overallTotal = getUpperSectionBonus() + getLowerSectionTotal() + getUpperSectionTotal();
		return overallTotal;
	}

	public int getUpperSectionBonus() {
		upperSecBonus = 0;
		if (configuration.getUpperSectionBonus() >= 1) {
			upperSecBonus = configuration.getUpperSectionBonus();
		} else {
			upperSecBonus = 0;
		}
		return upperSecBonus;
	}
}