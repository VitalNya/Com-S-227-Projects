package hw4;

import java.util.HashMap;
import java.util.Map;

import api.ScoreBox;

public class applicationClass implements ScoreBox {
	
	private int targetValue;
	private int total;
	private boolean fillRun = false;
	protected boolean isSatRun = false;
	protected Combination com;
	private String name;

	
	
	public applicationClass(String displayName, int whichValue) {
		targetValue = whichValue;
		name = displayName;
		
	}
	
	public applicationClass(String displayName)	{
		name = displayName;
	}
	
	
	
	public boolean isFilled() {
		if (fillRun) {
			return true;
		}
		return false;
	}

	
	public int getScore() {
		return getPotentialScore(com.getCompletedDice());
	}

	public Combination getDice() {
		return com;
	}

	public String getDisplayName() {
		return name;
	}
	
	
	/**
	 * This method will be inherited by different classes. When called 
	 * they may have different arrs or num(s) for their coditions. 
	 * Overall it will use a map to store values then refer to the map to
	 * count the frequency of that specific number. 
	 * 
	 * @param arr
	 * @param num1
	 * @param num2
	 * @return
	 */
	public int frequencyMap(int[] arr, int num1, int num2) {
		total = 0;
		isSatRun = false;
				
		// Use a HashMap to store the frequency of each dice value
		Map<Integer, Integer> frequencyMap = new HashMap<>();
		for (int num : arr) {
			frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
		}

		boolean firstCodition = false;
		boolean secondCondition = false;
		

		// Iterate through the frequency map
		for (int frequency : frequencyMap.values()) {
			if (frequency >= num1 && firstCodition != true) {
				firstCodition = true;
			} else if (frequency == num2 && secondCondition != true) {
				secondCondition = true;
			}
		}

		// If the coditions are both met, then total up all the numbers in the arr
		if (firstCodition && secondCondition) {
			for (int numb : arr) {
				total += numb;
				isSatRun = true;
			}
		}
		
		// return the totaled 
		return total;
		
	}


	public void fill(Combination dice) {
		com = dice;
		fillRun = true;
		
	}

	
	public boolean isSatisfiedBy(int[] arr) {
		return isSatRun = true;
	}
	

	public int getPotentialScore(int[] arr) { 
		total = 0;
		if (isSatisfiedBy(arr) != true) {
			return 0;
		}
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == targetValue) {
				total += targetValue;
			}
		}
		return total ;
	}
		

}
