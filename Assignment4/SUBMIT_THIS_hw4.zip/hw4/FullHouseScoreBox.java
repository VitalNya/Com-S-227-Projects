package hw4;

/**
 * Score box that is satisfied by a Combination including at least three dice of
 * one value and two of a different value. The score is the sum of all die
 * values.
 * 
 * @author VITAL NYABASHI
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class FullHouseScoreBox extends applicationClass {
	/**
	 * Constructs a FullHouseScoreBox with the given display name.
	 * 
	 * @param displayName name for this score box
	 */
	
	public FullHouseScoreBox(String displayName) {
		super(displayName);
	}

	@Override
	public boolean isSatisfiedBy(int[] arr) {
		getPotentialScore(arr);
		return isSatRun;
	}
	
	
	/*
	 * Details in the applicationClass class
	 */
	@Override
	public int getPotentialScore(int[] arr) {
		return frequencyMap(arr, 3, 2);
	}

}
