package hw4;

/**
 * Score box that is satisfied by a Combination including at least three dice of
 * one value and three of a different value. The score is the sum of all die
 * values.
 * 
 * @author VITAL NYABASHI
 */
//TODO: this class must implement ScoreBox or extend another class that does
public class CastleScoreBox extends applicationClass {
	/**
	 * Constructs a CastleScoreBox with the given display name.
	 * 
	 * @param displayName name for this score box
	 */
	public CastleScoreBox(String displayName) {
		super(displayName);
	}

	
	@Override
	public boolean isSatisfiedBy(int[] arr) {
		getPotentialScore(arr);
		return isSatRun;
	}
	
	/*
	 *  Details in the applicationClass class
	 */
	public int getPotentialScore(int[] dice) {
		return frequencyMap(dice, 3, 1);
	}
}
