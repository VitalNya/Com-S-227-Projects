package hw4;

import java.util.ArrayList;
import java.util.Arrays;

public class Combination {
	private int diceValues;
	private int[] initValues;
	private int[] completedDiceArray;
	private ArrayList<Integer> usedDice = new ArrayList<>();
	private boolean chooseAllRun = false;

	public Combination(int numDice) {
		diceValues = numDice;
		initValues = new int[diceValues];
	}

	public Combination(int[] initialValues) {
		diceValues = initialValues.length;
		initValues = new int[diceValues];
		for (int i = 0; i < initialValues.length; i++) {
			initValues[i] = initialValues[i];
		}
	}

	public int getNumDice() {
		return diceValues;
	}

	public void choose(int value) {
		for (int i = 0; i < initValues.length; i++) {
			if (initValues[i] == value) {
				boolean isUsed = false;
				for (int j = 0; j < usedDice.size(); j++) {	
					if (i == usedDice.get(j)) {
						isUsed = true;
						break;
					}
				}
				if (!isUsed) {
					usedDice.add(value);
					break;
				}
			}
		}
	}

	public void chooseAll() {
		if (chooseAllRun) {
			return;
		}

		usedDice.clear();

		for (int i = 0; i < initValues.length; i++) {
			usedDice.add(initValues[i]);
		}

		chooseAllRun = true;
	}

	public boolean isComplete() {
		return chooseAllRun;
	}

	public int[] getCompletedDice() {
		completedDiceArray = new int[usedDice.size()];
		for (int i = 0; i < usedDice.size(); i++) {
			completedDiceArray[i] = usedDice.get(i);
		}

		Arrays.sort(completedDiceArray);

		return completedDiceArray;
	}

	public int[] getAvailableDice() {
		ArrayList<Integer> clone = new ArrayList<>(usedDice);

		int availableCount = initValues.length - usedDice.size();
		int[] array = new int[availableCount < 0 ? 0 : availableCount];

		int count = 0;
		for (int i = 0; i < initValues.length; i++) {
			boolean useDice = true;
			for (int j = 0; j < clone.size(); j++) {
				if (initValues[i] == clone.get(j)) {
					useDice = false;
					clone.set(j, -1);
					break;
				}
			}
			if (useDice) {
				array[count] = initValues[i];
				count++;
			}
		}
		Arrays.sort(array);
		return array;
	}

	public int[] getAll() {
		Arrays.sort(initValues);
		return initValues.clone();
	}

	public void updateAvailableDice(int[] newValues) {
		int[] availableDice = getAvailableDice();

		if (newValues.length != availableDice.length) {
			throw new IllegalArgumentException("The number of new values must match the number of available dice.");
		}

		for (int i = 0; i < availableDice.length; i++) {
			for (int j = 0; j < initValues.length; j++) {
				if (initValues[j] == availableDice[i]) {
					initValues[j] = newValues[i];
					break;
				}
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		int[] avail = getAvailableDice();
		int[] completed = getCompletedDice();
		if (avail.length > 0) {
			for (int value : avail) {
				sb.append(value).append(" ");
			}
		}
		sb.append("(");
		if (completed.length > 0) {
			sb.append(completed[0]);
			for (int i = 1; i < completed.length; ++i) {
				sb.append(" ").append(completed[i]);
			}
		}
		sb.append(")");
		return sb.toString();
	}
}